package sets;

import java.util.Iterator;
import java.util.NoSuchElementException;

class LinkedNodeIterator<E> implements Iterator<E> {
    // TODO (1) define data variables
	private LinkedNode <E> temp_node;
  
  // Constructors
  public LinkedNodeIterator(LinkedNode<E> head) {
      // TODO (2) choose appropriate parameters and do the initialization
	  temp_node = head;
  }

  @Override
  public boolean hasNext() {
    // TODO (3)
	  
	  
    return temp_node!=null;
  }

  @Override
  public E next() {
    // TODO (4)
	  if(!hasNext())
    throw new NoSuchElementException();
	  E data = temp_node.getData();
	  temp_node = temp_node.getNext();
	  return data;
	  
  }

  @Override
  public void remove() {
    // Nothing to change for this method
    throw new UnsupportedOperationException();
  }
}
