package sets;

import java.util.Iterator;

/**
 * A LinkedList-based implementation of Set
 */

  /********************************************************
   * NOTE: Before you start, check the Set interface in
   * Set.java for detailed description of each method.
   *******************************************************/
  
  /********************************************************
   * NOTE: for this project you must use linked lists
   * implemented by yourself. You are NOT ALLOWED to use
   * Java arrays of any type, or any Collection-based class 
   * such as ArrayList, Vector etc. You will receive a 0
   * if you use any of them.
   *******************************************************/ 

  /********************************************************
   * NOTE: you are allowed to add new methods if necessary,
   * but do NOT add new files (as they will be ignored).
   *******************************************************/

public class LinkedSet<E> implements Set<E> {
  private LinkedNode<E> head = null;

  // Constructors
  public LinkedSet() {
  }

  public LinkedSet(E e) {
    this.head = new LinkedNode<E>(e, null);
  }

  private LinkedSet(LinkedNode<E> head) {
    this.head = head;
  }

  @Override
  public int size() {
	int counter = 0;
    Iterator<E> temp = iterator();
    while(temp.hasNext()) {
    	counter++;
    	temp.next();
    }
    return counter;
  }

  @Override
  public boolean isEmpty() {
    // TODO (2)
	  if(size() == 0) {
		  return true;
	  }
	  else 
		 return false;
    
  }

  @Override
  public Iterator<E> iterator() {
    return new LinkedNodeIterator<E>(this.head);
  }

  @Override
  public boolean contains(Object o) {
    // TODO (3)
	  Iterator<E> temp = iterator();
	  while(temp.hasNext()) {
		  if(temp.next().equals(o)) {
			  return true;
		  }
	  }
    return false;
  }

  @Override
  public boolean isSubset(Set<E> that) {
    // TODO (4)
	  Iterator<E> temp = iterator();
	  while(temp.hasNext()) {
		  if(!that.contains(temp.next())) {
			  return false;
		  }
	  }
    return true;
  }
  
  @Override
  public boolean isSuperset(Set<E> that) {
    // TODO (5)
	      return that.isSubset(this);
  }
  private E newIterator(Set<E> now, int size){
	  Iterator<E> temp = now.iterator();
	  E new_temp = null;
	  for(int i = 0; i<size;i++) {
		  new_temp = temp.next();
	  }
	  return new_temp;
  }

  @Override
  public Set<E> adjoin(E e) {
    // TODO (6)
	  LinkedNode<E> current;
	  LinkedNode<E> next = new LinkedNode<E>(e, null);
	  int flag=size();
	  	for(int i = 0; i<flag; i++) {
	  		E x = newIterator(this, flag-i);
	  	
	  	current = new LinkedNode<E>(x,next);
	  	next = current;
	  	}
	  	
LinkedSet<E> last = new LinkedSet<E>(next);
return last;
	  
  }

  @Override
  public Set<E> union(Set<E> that) {
    // TODO (7)
	  LinkedNode<E> current;
	  LinkedNode<E> next = null;
	  int size = size();
	  int temp_flag = that.size();
	  if(that.isSubset(this)) {
		  return this;
	  }
	  if(this.isSubset(that)) {
		  return that;
	  }
	  for(int i =0;i<size;i++){
		 E x = newIterator(this, size -i);
		 if(!that.contains(x)) {
			 current = new LinkedNode<E>(x, next);
			 next = current;
		 }
	  }
	  for(int i = 0; i< temp_flag;i++) {
		  E x = newIterator(that, temp_flag -i);
		  current = new LinkedNode<E>(x, next);
		  next = current;
	  }
	  LinkedSet<E> last = new LinkedSet<E>(next);
	  return last;
  }

  @Override
  public Set<E> intersect(Set<E> that) {
    // TODO (8)
	  LinkedNode<E> current;
	  LinkedNode<E> next = null;
	  int flag = size();
	  for(int i=0; i<flag;i++) {
		  E x = newIterator(this, flag -i);
		  if(that.contains(x)) {
			  current = new LinkedNode<E>(x,next);
			  next=current;
		  }
	  }
	  LinkedSet<E> last = new LinkedSet<E>(next);
	  return last;
  }

  @Override
  public Set<E> subtract(Set<E> that) {
    // TODO (9)
	  LinkedNode<E> current;
	  LinkedNode<E> next = null;
	  int flag = size();
	  for(int i =0;i <size();i++) {
		  E x = newIterator(this, size()-i);
		  if(!that.contains(x)) {
			  current = new LinkedNode(x, next);
			  next = current;
		  }
		  
	  }
	  LinkedSet<E> last = new LinkedSet<E>(next);
		  return last;
   
  }

  @Override
  public Set<E> remove(E e) {
    // TODO (10)
	  LinkedNode<E> current;
	  LinkedNode<E> next = null;
	  int flag = size();
	  	for(int i = 0; i< flag; i++) {
	  		E x = newIterator(this, flag-i);
	  		if(!x.equals(e)) {
	  			current = new LinkedNode<E> (x, next);
	  				next= current;
	  		}
	  	}
	  	LinkedSet<E> last = new LinkedSet<E>(next);
	  	return last;
  }

  @Override
  @SuppressWarnings("unchecked")
  public boolean equals(Object o) {
    if (! (o instanceof Set)) {
      return false;
    }
    Set<E> that = (Set<E>)o;
    return this.isSubset(that) && that.isSubset(this);
  }

  @Override
    public int hashCode() {
    int result = 0;
    for (E e : this) {
      result += e.hashCode();
    }
    return result;
  }
}
